package com.zangdaru.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;

/** List of doctor visits (separate from medicine reminders). */
public class AppointmentsActivity extends Activity {
    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    private void build() {
        final Ui.Pal p = Ui.pal(this);
        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad);
        sv.addView(col);

        col.addView(Ui.topBar(this, "مراجعه به پزشک"), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));
        TextView add = Ui.button(this, "➕  ثبت وقت پزشک", p.primary, Color.WHITE);
        add.setTextSize(22);
        add.setOnClickListener(v -> startActivity(new Intent(this, ApptEditActivity.class)));
        col.addView(add, Ui.lp(this, Ui.MATCH, Ui.dp(this, 68), 16));
        TextView hint = Ui.text(this, "۲۴ ساعت و ۲ ساعت قبل از وقت پزشک، زنگ یادآوری می‌خورد.", 15, p.text, false);
        col.addView(hint, Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));

        ArrayList<Appt> all = Store.allAppts(this);
        long now = System.currentTimeMillis();
        ArrayList<Appt> future = new ArrayList<>(), past = new ArrayList<>();
        for (Appt a : all) { if (a.millis() >= now) future.add(a); else past.add(a); }

        if (all.isEmpty()) {
            TextView e = Ui.text(this, "هنوز وقتی ثبت نکرده‌اید.", 18, p.text, false);
            e.setGravity(android.view.Gravity.CENTER);
            e.setPadding(pad, Ui.dp(this, 32), pad, Ui.dp(this, 32));
            col.addView(e, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        }
        for (Appt a : future) col.addView(card(a, p, true), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        if (!past.isEmpty()) {
            col.addView(Ui.text(this, "وقت‌های گذشته", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 24));
            for (int i = past.size() - 1; i >= 0; i--) col.addView(card(past.get(i), p, false), Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
        }
        Ui.apply(this, sv);
    }

    private android.view.View card(final Appt a, Ui.Pal p, boolean upcoming) {
        int pad = Ui.dp(this, 14);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.box(this, upcoming ? p.soft : 0xFFEEEEEE, 20));
        c.setPadding(pad, pad, pad, pad);
        c.addView(Ui.text(this, "🩺 " + a.doctor, 22, p.text, true));
        c.addView(Ui.text(this, "📅 " + Jalali.fmtFull(a.dateKey) + " - ساعت " + a.timeText(), 18, p.text, false));
        if (!a.note.isEmpty()) c.addView(Ui.text(this, a.note, 16, p.text, false));
        String st;
        if (!upcoming) st = "گذشته";
        else {
            long d = Jalali.epochDay(a.dateKey) - Jalali.epochDay(Jalali.todayKey());
            st = d == 0 ? "امروز" : d == 1 ? "فردا" : Jalali.fa(String.valueOf(d)) + " روز دیگر";
        }
        c.addView(Ui.text(this, st, 16, upcoming ? p.primary : 0xFF757575, true));
        c.setOnClickListener(v -> {
            Intent i = new Intent(this, ApptEditActivity.class);
            i.putExtra("id", a.id);
            startActivity(i);
        });
        return c;
    }
}
