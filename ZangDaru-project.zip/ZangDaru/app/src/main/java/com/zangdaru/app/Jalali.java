package com.zangdaru.app;

import java.util.Calendar;
import java.util.TimeZone;

/** Persian (Jalali / Shamsi) calendar helpers. Dates are kept as Gregorian "keys": yyyymmdd. */
final class Jalali {
    static final String[] MONTHS = {"فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
            "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"};
    static final String[] WEEKDAYS = {"شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"};
    static final String[] WD_SHORT = {"ش", "ی", "د", "س", "چ", "پ", "ج"};

    static int[] g2j(int gy, int gm, int gd) {
        int[] gdm = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};
        int gy2 = (gm > 2) ? (gy + 1) : gy;
        int days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gdm[gm - 1];
        int jy = -1595 + (33 * (days / 12053));
        days %= 12053;
        jy += 4 * (days / 1461);
        days %= 1461;
        if (days > 365) {
            jy += (days - 1) / 365;
            days = (days - 1) % 365;
        }
        int jm, jd;
        if (days < 186) {
            jm = 1 + days / 31;
            jd = 1 + days % 31;
        } else {
            jm = 7 + (days - 186) / 30;
            jd = 1 + (days - 186) % 30;
        }
        return new int[]{jy, jm, jd};
    }

    static int[] j2g(int jy, int jm, int jd) {
        jy += 1595;
        int days = -355668 + (365 * jy) + ((jy / 33) * 8) + (((jy % 33) + 3) / 4) + jd
                + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
        int gy = 400 * (days / 146097);
        days %= 146097;
        if (days > 36524) {
            gy += 100 * (--days / 36524);
            days %= 36524;
            if (days >= 365) days++;
        }
        gy += 4 * (days / 1461);
        days %= 1461;
        if (days > 365) {
            gy += (days - 1) / 365;
            days = (days - 1) % 365;
        }
        int gd = days + 1;
        boolean leap = (gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0);
        int[] sal = {0, 31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        int gm;
        for (gm = 0; gm < 13 && gd > sal[gm]; gm++) gd -= sal[gm];
        return new int[]{gy, gm, gd};
    }

    static int key(int gy, int gm, int gd) { return gy * 10000 + gm * 100 + gd; }

    static int[] unkey(int k) { return new int[]{k / 10000, (k / 100) % 100, k % 100}; }

    static int todayKey() {
        Calendar c = Calendar.getInstance();
        return key(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static int[] todayJ() {
        int[] g = unkey(todayKey());
        return g2j(g[0], g[1], g[2]);
    }

    private static Calendar utcNoon(int gy, int gm, int gd) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(gy, gm - 1, gd, 12, 0, 0);
        return c;
    }

    static long epochDay(int k) {
        int[] g = unkey(k);
        return Math.round(utcNoon(g[0], g[1], g[2]).getTimeInMillis() / 86400000.0);
    }

    /** 0 = Saturday ... 6 = Friday */
    static int weekdayIndexOfKey(int k) {
        int[] g = unkey(k);
        return utcNoon(g[0], g[1], g[2]).get(Calendar.DAY_OF_WEEK) % 7;
    }

    static boolean isLeap(int jy) {
        int[] a = j2g(jy, 1, 1), b = j2g(jy + 1, 1, 1);
        return epochDay(key(b[0], b[1], b[2])) - epochDay(key(a[0], a[1], a[2])) == 366;
    }

    static int monthLength(int jy, int jm) {
        if (jm <= 6) return 31;
        if (jm <= 11) return 30;
        return isLeap(jy) ? 30 : 29;
    }

    static int addDays(int k, int n) {
        int[] g = unkey(k);
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(g[0], g[1] - 1, g[2], 12, 0, 0);
        c.add(Calendar.DAY_OF_YEAR, n);
        return key(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static long millis(int k, int h, int mi) {
        int[] g = unkey(k);
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(g[0], g[1] - 1, g[2], h, mi, 0);
        return c.getTimeInMillis();
    }

    static String fa(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) sb.append(ch >= '0' && ch <= '9' ? (char) ('\u06F0' + (ch - '0')) : ch);
        return sb.toString();
    }

    /** e.g. "شنبه ۳۰ مهر ۱۴۰۵" */
    static String fmtFull(int k) {
        int[] g = unkey(k);
        int[] j = g2j(g[0], g[1], g[2]);
        return WEEKDAYS[weekdayIndexOfKey(k)] + " " + fa(String.valueOf(j[2])) + " " + MONTHS[j[1] - 1] + " " + fa(String.valueOf(j[0]));
    }

    /** e.g. "۱۴۰۵/۰۷/۳۰" */
    static String fmtShort(int k) {
        int[] g = unkey(k);
        int[] j = g2j(g[0], g[1], g[2]);
        return fa(String.format(java.util.Locale.US, "%04d/%02d/%02d", j[0], j[1], j[2]));
    }
}
