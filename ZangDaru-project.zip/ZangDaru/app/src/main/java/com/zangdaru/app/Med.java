package com.zangdaru.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;

final class Med {
    int id;
    String name = "", note = "", photo = "";
    ArrayList<String> times = new ArrayList<>();
    long startMs;
    int days = 7;                                   // used when dates is empty: every day for 'days' days
    ArrayList<Integer> dates = new ArrayList<>();   // chosen days from the calendar (Gregorian keys yyyymmdd)

    boolean hasPhoto() { return photo != null && !photo.isEmpty() && new File(photo).exists(); }

    boolean byDates() { return !dates.isEmpty(); }

    long endMs() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(startMs);
        c.add(Calendar.DAY_OF_YEAR, days);
        return c.getTimeInMillis();
    }

    int daysLeft() {
        if (byDates()) {
            int today = Jalali.todayKey(), n = 0;
            for (int k : dates) if (k >= today) n++;
            return n;
        }
        long d = endMs() - System.currentTimeMillis();
        return d <= 0 ? 0 : (int) Math.ceil(d / 86400000.0);
    }

    /** Every day (Gregorian key) on which this medicine is to be taken. */
    ArrayList<Integer> dayKeys() {
        if (byDates()) return new ArrayList<>(dates);
        ArrayList<Integer> l = new ArrayList<>();
        for (int d = 0; d < days; d++) {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(startMs);
            c.add(Calendar.DAY_OF_YEAR, d);
            l.add(Jalali.key(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)));
        }
        return l;
    }

    static long todayStart() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("note", note);
        o.put("photo", photo == null ? "" : photo);
        o.put("start", startMs);
        o.put("days", days);
        JSONArray a = new JSONArray();
        for (String t : times) a.put(t);
        o.put("times", a);
        JSONArray d = new JSONArray();
        for (int k : dates) d.put(k);
        o.put("dates", d);
        return o;
    }

    static Med from(JSONObject o) throws JSONException {
        Med m = new Med();
        m.id = o.getInt("id");
        m.name = o.optString("name", "");
        m.note = o.optString("note", "");
        m.photo = o.optString("photo", "");
        m.startMs = o.optLong("start", todayStart());
        m.days = o.optInt("days", 7);
        JSONArray a = o.optJSONArray("times");
        if (a != null) for (int i = 0; i < a.length(); i++) m.times.add(a.getString(i));
        JSONArray d = o.optJSONArray("dates");
        if (d != null) for (int i = 0; i < d.length(); i++) m.dates.add(d.getInt(i));
        return m;
    }
}
