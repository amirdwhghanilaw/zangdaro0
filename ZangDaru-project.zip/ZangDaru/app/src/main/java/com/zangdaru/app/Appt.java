package com.zangdaru.app;

import org.json.JSONException;
import org.json.JSONObject;

/** A doctor visit: doctor name, day (Gregorian key yyyymmdd) and time. */
final class Appt {
    int id;
    String doctor = "", note = "";
    int dateKey;
    int hour = 10, minute = 0;

    long millis() { return Jalali.millis(dateKey, hour, minute); }

    String timeText() { return Jalali.fa(Ui.hm(hour, minute)); }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("doctor", doctor);
        o.put("note", note);
        o.put("date", dateKey);
        o.put("h", hour);
        o.put("m", minute);
        return o;
    }

    static Appt from(JSONObject o) throws JSONException {
        Appt a = new Appt();
        a.id = o.getInt("id");
        a.doctor = o.optString("doctor", "");
        a.note = o.optString("note", "");
        a.dateKey = o.optInt("date", 0);
        a.hour = o.optInt("h", 10);
        a.minute = o.optInt("m", 0);
        return a;
    }
}
